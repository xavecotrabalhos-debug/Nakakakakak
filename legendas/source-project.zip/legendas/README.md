# Legendas Dinâmicas (100% offline e gratuito)
1. Suba esta pasta em um repositório GitHub (branch main).
2. Actions > Build APK > baixe o artefato "LegendasDinamicas-apk".
3. Instale o app-debug.apk. Não precisa de chave de API nem de internet.
