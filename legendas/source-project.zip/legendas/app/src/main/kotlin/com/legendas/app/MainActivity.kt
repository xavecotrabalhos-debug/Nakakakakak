@file:OptIn(androidx.media3.common.util.UnstableApi::class)
package com.legendas.app

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.content.res.AssetManager
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import androidx.media3.ui.PlayerView
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.*
import org.json.JSONObject
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder
import org.vosk.Model
import org.vosk.Recognizer
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

data class W(val t: String, val s: Double, val e: Double)

// Agrupa palavras em blocos de até 3 (quebra em pausas e pontuação)
fun chunk(ws: List<W>): List<List<W>> {
    val out = mutableListOf<MutableList<W>>()
    for (w in ws) {
        val c = out.lastOrNull()
        if (c == null || c.size >= 3 || w.s - c.last().e > 0.6 || c.last().t.last() in ".?!") out.add(mutableListOf(w)) else c.add(w)
    }
    return out
}

// Retorna (bloco, palavra ativa) no instante t
fun find(ch: List<List<W>>, t: Double): Pair<Int, Int>? {
    val i = ch.indexOfLast { it.first().s <= t }
    if (i < 0 || t > ch[i].last().e + 0.3) return null
    return i to ch[i].indexOfLast { it.s <= t }
}

// Desenha o bloco com a palavra ativa em amarelo e maior
fun render(words: List<W>, j: Int, w: Int, h: Int): Bitmap {
    val bm = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    val c = Canvas(bm)
    val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD) }
    fun total(sz: Float) = words.mapIndexed { i, x -> p.textSize = if (i == j) sz * 1.2f else sz; p.measureText(x.t + " ") }.sum()
    var size = w * 0.075f
    while (total(size) > w * 0.9f && size > 10f) size *= 0.9f
    var x = (w - total(size)) / 2f
    val y = h * 0.72f
    words.forEachIndexed { i, wd ->
        p.textSize = if (i == j) size * 1.2f else size
        p.style = Paint.Style.STROKE; p.strokeWidth = p.textSize * 0.18f; p.color = Color.BLACK
        c.drawText(wd.t, x, y, p)
        p.style = Paint.Style.FILL; p.color = if (i == j) Color.rgb(255, 230, 0) else Color.WHITE
        c.drawText(wd.t, x, y, p)
        x += p.measureText(wd.t + " ")
    }
    return bm
}

class CaptionOverlay(val ch: List<List<W>>, val w: Int, val h: Int) : BitmapOverlay() {
    private var key = -2
    private var bm: Bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val f = find(ch, presentationTimeUs / 1e6)
        val k = if (f == null) -1 else f.first * 10 + f.second
        if (k != key) {
            key = k
            bm = if (f == null) Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888) else render(ch[f.first], f.second, w, h)
        }
        return bm
    }
}

suspend fun runT(ctx: Context, item: EditedMediaItem, out: String) = suspendCancellableCoroutine<Unit> { c ->
    Transformer.Builder(ctx).addListener(object : Transformer.Listener {
        override fun onCompleted(composition: Composition, exportResult: ExportResult) { c.resume(Unit) }
        override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) { c.resumeWithException(exportException) }
    }).build().start(item, out)
}

// Decodifica o áudio do vídeo para PCM 16 kHz mono e entrega em pedaços
fun pcm16k(ctx: Context, uri: Uri, sink: (ByteArray, Int) -> Unit) {
    val ex = MediaExtractor(); ex.setDataSource(ctx, uri, null)
    val ti = (0 until ex.trackCount).first { ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)!!.startsWith("audio/") }
    ex.selectTrack(ti)
    val fmt = ex.getTrackFormat(ti)
    val codec = MediaCodec.createDecoderByType(fmt.getString(MediaFormat.KEY_MIME)!!)
    codec.configure(fmt, null, null, 0); codec.start()
    var rate = fmt.getInteger(MediaFormat.KEY_SAMPLE_RATE)
    var chs = fmt.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    val info = MediaCodec.BufferInfo()
    var inDone = false; var outDone = false
    var sum = 0.0; var cnt = 0; var acc = 0.0
    while (!outDone) {
        if (!inDone) {
            val i = codec.dequeueInputBuffer(10000)
            if (i >= 0) {
                val n = ex.readSampleData(codec.getInputBuffer(i)!!, 0)
                if (n < 0) { codec.queueInputBuffer(i, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM); inDone = true }
                else { codec.queueInputBuffer(i, 0, n, ex.sampleTime, 0); ex.advance() }
            }
        }
        val o = codec.dequeueOutputBuffer(info, 10000)
        if (o >= 0) {
            val ob = codec.getOutputBuffer(o)!!
            ob.position(info.offset); ob.limit(info.offset + info.size)
            val sb = ob.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
            val frames = sb.remaining() / chs
            val step = rate / 16000.0
            val out = ByteBuffer.allocate(((frames / step).toInt() + 4) * 2).order(ByteOrder.LITTLE_ENDIAN)
            for (f in 0 until frames) {
                var m = 0.0
                for (c in 0 until chs) m += sb.get(f * chs + c)
                sum += m / chs; cnt++; acc += 1.0
                if (acc >= step) { out.putShort((sum / cnt).toInt().toShort()); sum = 0.0; cnt = 0; acc -= step }
            }
            if (out.position() > 0) sink(out.array(), out.position())
            codec.releaseOutputBuffer(o, false)
            if (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM != 0) outDone = true
        } else if (o == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
            rate = codec.outputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            chs = codec.outputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        }
    }
    codec.stop(); codec.release(); ex.release()
}

fun copyAssets(am: AssetManager, path: String, dest: File) {
    val list = am.list(path) ?: emptyArray()
    if (list.isEmpty()) {
        try { am.open(path).use { i -> dest.outputStream().use { i.copyTo(it) } } } catch (e: Exception) { dest.mkdirs() }
    } else {
        dest.mkdirs()
        for (n in list) copyAssets(am, "$path/$n", File(dest, n))
    }
}

// Transcrição 100% offline com Vosk (palavra por palavra, com tempos)
fun transcribe(ctx: Context, uri: Uri): List<W> {
    val dir = File(ctx.filesDir, "model")
    val ok = File(ctx.filesDir, "model.ok")
    if (!ok.exists()) { dir.deleteRecursively(); copyAssets(ctx.assets, "model", dir); ok.writeText("1") }
    val model = Model(dir.path)
    val rec = Recognizer(model, 16000f)
    rec.setWords(true)
    val out = mutableListOf<W>()
    fun take(j: String) {
        val a = JSONObject(j).optJSONArray("result") ?: return
        for (i in 0 until a.length()) a.getJSONObject(i).let { out.add(W(it.getString("word").uppercase(), it.getDouble("start"), it.getDouble("end"))) }
    }
    pcm16k(ctx, uri) { b, n -> if (rec.acceptWaveForm(b, n)) take(rec.result) }
    take(rec.finalResult)
    rec.close(); model.close()
    return out
}

fun vsize(ctx: Context, u: Uri): Pair<Int, Int> {
    val m = MediaMetadataRetriever(); m.setDataSource(ctx, u)
    var w = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
    var h = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
    val r = m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toInt() ?: 0
    m.release()
    if (r == 90 || r == 270) { val t = w; w = h; h = t }
    return w to h
}

fun save(ctx: Context, f: File) {
    val v = ContentValues().apply {
        put(MediaStore.Video.Media.DISPLAY_NAME, "legendado_${System.currentTimeMillis()}.mp4")
        put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
        put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Legendas")
    }
    val u = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
    ctx.contentResolver.openOutputStream(u)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { App() } }
    }
}

@Composable
fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var uri by remember { mutableStateOf<Uri?>(null) }
    var ch by remember { mutableStateOf<List<List<W>>>(emptyList()) }
    var status by remember { mutableStateOf("Escolha um vídeo") }
    var busy by remember { mutableStateOf(false) }
    var pos by remember { mutableStateOf(0.0) }
    val exo = remember { ExoPlayer.Builder(ctx).build() }
    DisposableEffect(Unit) { onDispose { exo.release() } }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) { uri = u; ch = emptyList(); exo.setMediaItem(MediaItem.fromUri(u)); exo.prepare(); status = "Vídeo carregado" }
    }
    LaunchedEffect(Unit) { while (true) { pos = exo.currentPosition / 1000.0; delay(40) } }
    fun launchJob(block: suspend () -> Unit) {
        scope.launch { busy = true; try { block() } catch (e: Throwable) { status = "Erro: ${e.message}" }; busy = false }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Legendas Dinâmicas", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Button({ pick.launch("video/*") }, enabled = !busy) { Text("Escolher vídeo") }
        if (uri != null) Box(Modifier.fillMaxWidth().height(420.dp)) {
            AndroidView({ PlayerView(it).apply { player = exo } }, Modifier.fillMaxSize())
            val f = find(ch, pos)
            if (f != null) Row(Modifier.align(Alignment.BottomCenter).padding(bottom = 90.dp)) {
                ch[f.first].forEachIndexed { i, w ->
                    val on = i == f.second
                    Text(w.t + " ", color = if (on) androidx.compose.ui.graphics.Color.Yellow else androidx.compose.ui.graphics.Color.White,
                        fontSize = if (on) 30.sp else 24.sp, fontWeight = FontWeight.Black)
                }
            }
        }
        Button(enabled = !busy && uri != null, onClick = {
            launchJob {
                status = "Transcrevendo no celular (a 1ª vez prepara o modelo)..."
                val ws = withContext(Dispatchers.IO) { transcribe(ctx, uri!!) }
                ch = chunk(ws); status = "Pronto: ${ws.size} palavras. Dê play para ver a prévia."
            }
        }) { Text("1. Gerar legendas (offline)") }
        Button(enabled = !busy && ch.isNotEmpty(), onClick = {
            launchJob {
                status = "Exportando (pode demorar)..."
                val (vw, vh) = vsize(ctx, uri!!)
                val k = minOf(1f, 1920f / maxOf(vw, vh))
                val ov = CaptionOverlay(ch, (vw * k).toInt(), (vh * k).toInt())
                val fx = Effects(emptyList(), listOf<Effect>(OverlayEffect(ImmutableList.of<TextureOverlay>(ov))))
                val item = EditedMediaItem.Builder(MediaItem.fromUri(uri!!)).setEffects(fx).build()
                val o = File(ctx.cacheDir, "out.mp4").apply { delete() }
                runT(ctx, item, o.path)
                withContext(Dispatchers.IO) { save(ctx, o) }
                status = "Salvo na galeria: Movies/Legendas"
            }
        }) { Text("2. Exportar vídeo legendado") }
        Text(status)
    }
}
