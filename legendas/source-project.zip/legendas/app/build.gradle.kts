plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.legendas.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.legendas.app"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
    sourceSets["main"].java.srcDir("src/main/kotlin")
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    implementation("com.alphacephei:vosk-android:0.3.47")
    implementation("net.java.dev.jna:jna:5.13.0@aar")
    val m = "1.4.1"
    implementation("androidx.media3:media3-exoplayer:$m")
    implementation("androidx.media3:media3-ui:$m")
    implementation("androidx.media3:media3-transformer:$m")
    implementation("androidx.media3:media3-effect:$m")
    implementation("androidx.media3:media3-common:$m")
}
